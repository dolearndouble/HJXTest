﻿using Microsoft.EntityFrameworkCore;

namespace slotsshare
{


    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        // 定义一个 DbSet，映射到 Invites 表
        public DbSet<Invite> Invites { get; set; }
    }

    public class Invite
    {
        public int Id { get; set; }          // 对应表中的 id 字段
        public string? ParentCode { get; set; }  // 对应表中的 parentcode 字段
        public string? ChildCode { get; set; }   // 对应表中的 childcode 字段
    }


}
