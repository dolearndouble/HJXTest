﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json.Linq;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace slotsshare.Controllers
{
    [Route("api/[controller]/[action]")]
    public class InviteController : Controller
    {
        private readonly HttpClient _httpClient;
        private readonly ApplicationDbContext _context;

        // 通过依赖注入将 HttpClient 和 DbContext 注入到控制器
        public InviteController(HttpClient httpClient, ApplicationDbContext context)
        {
            _httpClient = httpClient;
            _context = context;
        }

        // 异步方法用于处理邀请
        [HttpGet]
        public async Task<string> Invite(string parentcode,string childcode)
        {
            var inviteStr = parentcode;
            Console.WriteLine("inviteStr " + inviteStr);

            if (string.IsNullOrEmpty(inviteStr))
            {
                return "invite failed";
            }

            // 在数据库中查找是否存在匹配的 InviteCode
            var invite = await _context.Invites.FirstOrDefaultAsync(i => i.ParentCode == inviteStr && i.ChildCode==childcode);
            if (invite != null)
            {
                return "invite failed - already give coin";
            }

            // 动态构建 URL
            string url = $"http://127.0.0.1:3080/api/notice?notice_type=0&account_id={inviteStr}&data=%5b%7b%22type%22%3a12%2c%22value%22%3a12500%7d%5d";
            Console.WriteLine("url : " + url);

            try
            {
                // 使用 HttpClient 发送 HTTP GET 请求
                HttpResponseMessage response = await _httpClient.GetAsync(url);

                // 检查响应是否成功
                if (response.IsSuccessStatusCode)
                {
                    string content = await response.Content.ReadAsStringAsync();

                    Console.WriteLine("请求结果： " + content);
                    // 解析 JSON 数据
                    JObject jobject = JObject.Parse(content);
                    int num = jobject.Value<int>("code");
                    if (num == 0)
                    {
                        // 当请求成功时，插入一条新数据到数据库
                        var newInvite = new Invite
                        {
                            ParentCode = parentcode,
                            ChildCode = childcode
                        };

                        // 将新数据添加到上下文
                        await _context.Invites.AddAsync(newInvite);
                        // 保存更改
                        await _context.SaveChangesAsync();
                        return "invite success";
                    }
                    else
                    {
                        return "invite failed";
                    }
                }
                else
                {
                    return "invite failed - external request failed";
                }
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine("Request error: " + e.Message);
                return "invite failed - exception occurred";
            }
        }

        [HttpGet]
        public string Login(string pwd)
        {
            if (pwd == "123456")
            {
                return "登录成功！";
            }
            return "登录失败";
        }
    }
}

//using Microsoft.AspNetCore.Mvc;
//using Newtonsoft.Json.Linq;
//using System;
//using System.Net.Http;
//using System.Threading.Tasks;

//namespace slotsshare.Controllers
//{
//    [Route("api/[controller]/[action]")]
//    public class InviteController : Controller
//    {
//        private readonly HttpClient _httpClient;

//        // 通过依赖注入将 HttpClient 注入到控制器
//        public InviteController(HttpClient httpClient)
//        {
//            _httpClient = httpClient;
//        }

//        // 异步方法用于处理邀请
//        [HttpGet]
//        public async Task<string> Invite(string code)
//        {
//            var inviteStr = code;

//            Console.WriteLine("inviteStr " + inviteStr);

//            if (string.IsNullOrEmpty(inviteStr))
//            {
//                return "invite failed";
//            }

//            // 动态构建 URL
//            string url = $"http://127.0.0.1:3080/api/notice?notice_type=0&account_id={inviteStr}&data=%5b%7b%22type%22%3a12%2c%22value%22%3a12500%7d%5d";
//            Console.WriteLine("url : " + url);

//            try
//            {
//                // 使用 HttpClient 发送 HTTP GET 请求
//                HttpResponseMessage response = await _httpClient.GetAsync(url);

//                // 检查响应是否成功
//                if (response.IsSuccessStatusCode)
//                {
//                    string content = await response.Content.ReadAsStringAsync();

//                    Console.WriteLine("请求结果： "+content);
//                    // 解析 JSON 数据
//                    JObject jobject = JObject.Parse(content);
//                    int num = jobject.Value<int>("code");
//                    if (num == 0)
//                    {
//                        return "invite success";

//                    }
//                    else
//                    {
//                        return "invite failed";
//                    }

//                }
//                else
//                {
//                    return "invite failed - external request failed";
//                }
//            }
//            catch (HttpRequestException e)
//            {
//                Console.WriteLine("Request error: " + e.Message);
//                return "invite failed - exception occurred";
//            }
//        }

//        [HttpGet]
//        public string Login(string pwd)
//        {
//            if (pwd == "123456")
//            {
//                return "登录成功！";
//            }
//            return "登录失败";
//        }
//    }
//}


